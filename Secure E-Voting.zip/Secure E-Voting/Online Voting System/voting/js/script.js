
// for menu show
function showMenu()
{
    document.getElementById("menu").style.width="15rem";
    document.getElementById("show").style.display="none";
    document.getElementById("hide").style.display="inline";
    document.getElementById("main").style.width="80%";
}

// for menu hide
function hideMenu()
{
    document.getElementById("menu").style.width="0rem";
    document.getElementById("show").style.display="inline";
    document.getElementById("hide").style.display="none";
    document.getElementById("main").style.width="100%";
}

// for profile panel show
function showProfile()
{
    document.getElementById("profile-panel").style.height="18rem"
}

// for profile panel show
function hidePanel()
{
    document.getElementById("profile-panel").style.height="0rem"
}

